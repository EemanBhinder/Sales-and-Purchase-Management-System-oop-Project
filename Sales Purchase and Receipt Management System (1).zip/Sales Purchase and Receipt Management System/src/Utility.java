import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Utility implements Serializable
{
    //....................................Method to Modify Account Details of Owner................................
    public static boolean updateBalances(Double updatedBalance, Double updatedRevenue) {
        try {
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream("OwnerRecord.txt"));
            Owner owner = (Owner) ois.readObject();
            ois.close();

            owner.accBalance = updatedBalance;
            owner.totalRevenue = updatedRevenue;

            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("OwnerRecord.txt"));
            oos.writeObject(owner);
            oos.close();

            return true; // Success
        } catch (Exception e) {
            System.out.println("Error with File");
            return false; // Failure
        }
    }

    //.........................................Method to Show ProductStock........................................
    public static ArrayList<Product> showProductStock() {
        ArrayList<Product> productList = new ArrayList<>();

        try {
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream("ProductStore.txt"));

            try {
                while (true) {
                    productList.addAll((ArrayList<Product>) ois.readObject());
                }
            } catch (EOFException e) {
                // No more objects in the file, so continue execution
            }

            ois.close();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return productList;
    }
    // Input validation methods............................

    //..........................................Method to Validate Name......................................
    public static String verifyName(String name)
    {
        Scanner input = new Scanner(System.in);
        int count;
        //Validating only alphabets in input.............................................
        while(true)
        {
            if(name.length() > 30)
            {
                return "NULL";
            }
            else
                break;
        }
        while(true)
        {
            count = 0;
            for(int i =0; i < name.length(); i++)
            {
                if (!(Character.isLetter(name.charAt(i)) || name.charAt(i) == '.'  || name.charAt(i) == ' '))
                {

                    count++;
                    break;
                }
            }
            if (count != 0)
            {
               return "NULL";
            }
            else
                break;
        }
        return name;
    }
    //........................................Method to Validate Phone Number................................
    public static String verifyPhone(String contactNumber)
    {
        Scanner input = new Scanner(System.in);
        int count;
        //Validation of Correct format of phone Number.........
        while(true)
        {
            if (!((contactNumber.length() == 12 && contactNumber.charAt(4) == '-' && contactNumber.charAt(0) == '0'
                    && contactNumber.charAt(1) == '3')&&(contactNumber.charAt(2) == '0' || contactNumber.charAt(2) == '2' ||
                    contactNumber.charAt(2) == '1' || contactNumber.charAt(2) == '4' || contactNumber.charAt(2) == '3')))
            {
                return "NULL";
            }
            else
            {
                count = 0;
                for(int i =0; i < contactNumber.length(); i++)
                {
                    if (!(Character.isDigit(contactNumber.charAt(i))))
                    {
                        if (i == 4)
                        {
                            continue;
                        }
                        count++;
                        break;
                    }
                }
                if (count != 0)
                {
                    return "NULL";
                }
                else
                {
                    break;
                }
            }
        }
        return contactNumber;
    }

    //..........................................Method to Validate Email.....................................
    public static String verifyEmail(String email)
    {
        Scanner input = new Scanner(System.in);
        int count = 0;

        while (true)
        {
            boolean containsAtSymbol = false;

            for (int i = 0; i < email.length(); i++)
            {
                if (email.charAt(i) == '@')
                {
                    containsAtSymbol = true;
                    break;
                }
            }

            if (email.length() <= 10 || !containsAtSymbol)
            {
                return "NULL";
            }
            else
            {
                break;
            }
        }

        while (true)
        {
            for (int i = 0; i < email.length(); i++)
            {
                char c = email.charAt(i);

                if (!(Character.isLetter(c) || Character.isDigit(c) || c == '.' || c == '@' || c == '-'))
                {
                    count++;
                    break;
                }
            }
            if (count != 0)
            {
                return "NULL";
            }
            else
            {
                break;
            }
        }

        return email;
    }
}
