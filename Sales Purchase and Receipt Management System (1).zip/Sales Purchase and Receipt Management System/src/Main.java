
import javax.swing.*;
import java.awt.*;
import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    {
        MainFrame frame = new MainFrame();
//          Owner O1 = new Owner();
//        System.out.println(O1.displayAccount());;

//        frame.setVisible(true);
//        frame.setSize(520,520);
//        frame.setTitle("Sales,Purchase and Receipt Management System");
//        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        frame.setResizable(false);
//
//        ImageIcon logo = new ImageIcon("Logo.png");
//        frame.setIconImage(logo.getImage());
//
//        frame.getContentPane().setBackground(Color.lightGray);
//        frame.getContentPane().setBackground(new Color(0,0,50));
//        String name;
//        String phone;
//        String email;
//        String id;
//        Scanner input = new Scanner(System.in);
//        System.out.print("Enter Name: ");
//        name = input.nextLine();
//        System.out.print("\nEnter Phone\n(Format 0000-0000000): ");
//        phone = input.nextLine();
//        System.out.print("\nEnter Email: ");
//        email = input.nextLine();
//        Person P1 = new Person(name,phone,email);
//        P1.display();
//

//        O1.showProductStock();
//        SalesPerson S1 = new SalesPerson();
//        O1.showSalesPerson();
//        O1.showProductStock();
//        if (S1.login("wajahatalipk5@gmail.com","150ESB22PS"))
//        {
//            System.out.println("SuccessFull");
//        }
//        else
//        {
//            System.out.println("Failed");
//        }

//        S1.startPurchase();
//        S1.startPurchase();
//        S1.startPurchase();
//        System.out.println();
//        Owner.displayAccount();
//        O1.showProductStock();

//        O1.salesRecord();
//        O1.deleteSalesRecord();
//        O1.salesRecord();
//        Receipt rc = new Receipt();
//        System.out.println(rc.getSalesOfficer().getName());
//        Owner.displayAccount();
//        Utility.updateBalances(50000.0,3000.0);
//        Owner.displayAccount();


//        Customer C1 = new Customer("Sudais","0332-3412345","sudaisKan@gmail.com","001");
//        C1.display();
//
//        SalesPerson salesPerson = new SalesPerson("Kamran","0331-1234567","kamrankhan@gmail.com","001");
//        salesPerson.display();
//
//        Supplier S1 = new Supplier("Ali","0334-5678900","basitalipk5@gmail.com","0001");
//        S1.display();
//        Supplier S2 = new Supplier("Wajahat Ali","0334-5678900","basitalipk5@gmail.com","0002");
//
//        Product Panadol = new Product("Panadol",70,10,100,"Tablets for Headache",S2);
//        Panadol.display();
//
//        Product Brufen = new Product("Brufen",150,1,250,"Syrup For Fever",S1);
//        Brufen.display();
//
//
//        Store store = new Store("Hamd Pharmacy","Islamabad",new Product[]{Panadol,Brufen},new SalesPerson[]{salesPerson});
//        store.display();
//
//        //Owner's Operations............................................................................
//        O1.showStock();
//        O1.dailyRevenue();
//
//        Receipt R1 = new Receipt(1,"18-05-2023",new Product[]{Panadol},0,new int[]{2},"BY Cash",C1,salesPerson,store);
//
//        O1.dailyRevenue();
//
//        O1.addNewProduct();
//        O1.addNewProduct();
//        O1.showProductStock();
//        O1.deleteProduct();
//        O1.showProductStock();


//        S1.updateLogin("wajahatali@gmail.com","wajahat1214");
//        O1.deleteSalesPerson();
//        O1.addSalesPerson();
//        O1.addSalesPerson();
//        O1.addSalesPerson();
//        O1.addSalesPerson();
//        O1.showSalesPerson();
//        O1.displayAccount();
//        O1.displayAccount();
//        O1.updateLogin("majid@yahoo.com","majid@1214");
//        O1.displayAccount();
//        O1.showProductStock();
//        O1.addExistingProduct();
//        O1.showProductStock();
//
//        //Customer's Operations.........................................................................
//        //If Customer Chooses to Go for Purchase:.......................................................
//
//        SalesPerson.startPurchase(salesPerson);
    }
}

