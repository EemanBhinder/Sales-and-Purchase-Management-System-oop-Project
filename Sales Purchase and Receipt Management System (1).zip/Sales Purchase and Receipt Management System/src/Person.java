import java.io.*;
import java.util.Scanner;

public class Person implements Serializable
{
    private static final long serialVersionUID = -4037640016983222511L;



    protected String name;
    protected String phone;
    protected String email;

    // Constructor.................................
    public Person()
    {
        name = "NULL";
        phone = "0000-0000000";
        email = "null@gmail.com";
    }
    public Person(String name, String phone, String email)
    {
        this.name = Utility.verifyName(name);
        this.phone = Utility.verifyPhone(phone);
        this.email = Utility.verifyEmail(email);
    }

    // Getters...................................
    public String getName()
    {
        return name;
    }
    public String getPhone()
    {
        return phone;
    }
    public String getEmail()
    {
        return email;
    }

    //.....................Display Method...................................................................
    public String toString()
    {
        String value = "Name: " + name;
        value += "\nPhone: " + phone;
        value += "\nEmail: " + email;
        return value;
    }
}
