
import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class SalesPerson extends Person implements LoginInterface, Serializable
{
    private static final long serialVersionUID = 7194050316026614779L;


    private String ID;
    private String password;
    public SalesPerson()
    {
        super();
        ID = "admin";
        password = "0000";
    }
    public SalesPerson(String name, String phone, String email, String ID, String password)
    {
        super(name, phone, email);
        this.ID = ID;
        this.password = password;
    }
    //Creating Setter and Getter Methods.
    public void setID(String ID)
    {
        this.ID = ID;
    }
    public void setPassword(String password)
    {
        this.password = password;
    }
    public String getID()
    {
        return ID;
    }
    public String getPassword()
    {
        return password;
    }
    //...................................Method for Login....................................................
    @Override
    public boolean login(String email, String password)
    {
        ArrayList<SalesPerson> salesPersons;
        try
        {
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream("SalesPersonRecord.txt"));

            try
            {
                while (true)
                {
                    salesPersons = (ArrayList<SalesPerson>) ois.readObject();
                    for (SalesPerson salesPeople : salesPersons)
                    {
                        if(salesPeople.getEmail().equalsIgnoreCase(email) && salesPeople.getPassword().equals(password))
                        {
                            Receipt.salesOfficer = salesPeople;
                            return true;
                        }
                    }
                }
            }
            catch (EOFException e)
            {
                // No more objects in the file, so continue execution
            }

            ois.close();
        }
        catch (IOException | ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return false;
    }
    //...................................Method for Update Login.............................................
    @Override
    public boolean updateLogin(String existingEmail, String existingPassword, String newMail, String newPassword) {
        ArrayList<SalesPerson> salesPersons = new ArrayList<>();
        boolean isUpdated = false;

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("SalesPersonRecord.txt"))) {
            try {
                while (true) {
                    ArrayList<SalesPerson> salesPeople = (ArrayList<SalesPerson>) ois.readObject();
                    for (SalesPerson salesPerson : salesPeople) {
                        if (salesPerson.getEmail().equalsIgnoreCase(existingEmail) && salesPerson.getPassword().equals(existingPassword)) {
                            salesPerson.email = newMail;
                            salesPerson.setPassword(newPassword);
                            isUpdated = true;
                            break;
                        }
                    }
                    salesPersons.addAll(salesPeople);
                }
            } catch (EOFException e) {
                // No more objects in the file, so continue execution
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (isUpdated) {
            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("SalesPersonRecord.txt"))) {
                oos.writeObject(salesPersons); // Write the updated list to the file
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

        return isUpdated;
    }


    // ..................................Method for SalesPerson to Start Order...............................

    public static Receipt startPurchase(String name, String phone, String email, String id, ArrayList<Product> orderedProducts, String PaymentMethod) {
        Customer C2 = new Customer(name, phone, email, id);

        LocalDate currentDate = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        String date = currentDate.format(formatter);

        Receipt recept = new Receipt();
        recept.customer = C2;
        recept.date = date;
        recept.paymentMethod = PaymentMethod;


        double totalBill = 0;

            boolean productFound = false;
            ArrayList<Product> ProductStock = new ArrayList<>();
            ArrayList<Product> cartProduct = new ArrayList<>();
            try {
                ObjectInputStream ois = new ObjectInputStream(new FileInputStream("ProductStore.txt"));
                ProductStock = (ArrayList<Product>) ois.readObject();
                for (Product ordered : orderedProducts) {
                    for (Product stock : ProductStock) {
                        if (ordered.getProductName().equalsIgnoreCase(stock.getProductName()) && ordered.getQuantityInStock() <= stock.getQuantityInStock()) {
                            productFound = true;
                            Product productForCart = new Product(); // Create a new Product object
                            productForCart.setProductName(stock.getProductName());
                            productForCart.setProductPrice(stock.getProductPrice());
                            productForCart.setQuantity(ordered.getQuantityInStock());
                            totalBill += ordered.getQuantityInStock() * stock.getProductPrice();
                            stock.setQuantity(stock.getQuantityInStock() - ordered.getQuantityInStock());
                            cartProduct.add(productForCart);
                        }

                    }
                }
            }
            catch(Exception e)
            {
                System.out.println(e);
            }

            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("ProductStore.txt"))) {
                oos.writeObject(ProductStock);
                oos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

        try {
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream("OwnerRecord.txt"));
            Owner owner;
            owner = (Owner) ois.readObject();
            double newBalance = owner.getAccBalance() + totalBill;
            double newRevenue = owner.getTotalRevenue() + totalBill;
            ois.close();
            Utility.updateBalances(newBalance, newRevenue);

        } catch (IOException | ClassNotFoundException e) {
            System.out.println(e);
        }


        recept.cart = cartProduct;
        recept.amount = totalBill;

        ArrayList<Receipt> salesRecord = new ArrayList<>();

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("SalesRecord.txt"))) {
            salesRecord = (ArrayList<Receipt>) ois.readObject();
        } catch (FileNotFoundException e) {
            salesRecord = new ArrayList<>();
        } catch (EOFException e) {
            salesRecord = new ArrayList<>();
        } catch (Exception e) {
            e.printStackTrace();
        }

        salesRecord.add(recept);

        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("SalesRecord.txt"))) {
            oos.writeObject(salesRecord);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }


        return recept;
    }


    @Override
    public String toString() {
        String displayString = "Sales Person " + super.toString() + "\n" +
                "SalesPerson ID: " + ID + "\n" +
                "SalesPerson Password: " + getPassword() + "\n" +
                ".........................................";
        return displayString;
    }

}