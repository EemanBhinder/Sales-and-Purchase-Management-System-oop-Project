import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;

class Owner extends Person implements LoginInterface,Serializable
{
    private static final long serialVersionUID = 3436446231500268890L;


    protected   String password;
    protected   double accBalance;
    protected  double totalRevenue;

    //Non parametrized constructor
    public Owner()
    {
        super();
        password = "0000";
        accBalance = 0;
        totalRevenue = 0;
    }
    //Parametrized constructor
    public Owner(String name, String phone, String email,String password, double accBalance,double totalRevenue)
    {
        super(name, phone, email);
        this.password = password;
        this.accBalance = accBalance;
        this.totalRevenue = totalRevenue;
    }
    public void setPassword(String password)
    {
        this.password = password;
    }
    public void setAccBalance(double accBalance)
    {
        this.accBalance= accBalance;
    }
    public void setTotalRevenue(double totalRevenue)
    {
        this.totalRevenue = totalRevenue;
    }
    public  String getPassword()
    {
        return password;
    }
    public  double getAccBalance()
    {
        return accBalance;
    }
    public double getTotalRevenue()
    {
        return totalRevenue;
    }
    //..............................................Method for Login..............................................

    @Override
    public boolean login(String username, String password)
    {
        try
        {
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream("OwnerRecord.txt"));
            Owner owner = new Owner();
            owner = (Owner) ois.readObject();
            if(owner.getEmail().equalsIgnoreCase(username) && owner.getPassword().equals(password))
            {
                return true;
            }
            else
            {
                return false;
            }

        }
        catch(IOException | ClassNotFoundException e)
        {
            System.out.println(e);
        }
        return false;
    }
    //............................................Method for Update Login.........................................
    @Override
    public boolean updateLogin(String mail, String password,String newEmail,String newPassword) {
        Owner owner = new Owner();
        try {
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream("OwnerRecord.txt"));
            owner = (Owner) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println(e);
        }

        owner.email = Utility.verifyEmail(newEmail);
        owner.setPassword(newPassword);
        try {
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("OwnerRecord.txt"));
            oos.writeObject(owner);
            oos.close();
            return true; // Update successful
        } catch (Exception e) {
            System.out.println("Error with File");
            return false; // Update failed
        }
    }

    //............................................Method to Add New Product...........................................
    public void addNewProduct(Product newProduct) {
        ArrayList<Product> products = new ArrayList<>();

        // Read existing products from file (if any)
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("ProductStore.txt"))) {
            products = (ArrayList<Product>) ois.readObject();
        } catch (EOFException e) {
            // Handle the case where the file is empty
            products = new ArrayList<>();
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Append new product to the existing list
        products.add(newProduct);

        // Write the updated list to the file
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("ProductStore.txt"))) {
            oos.writeObject(products);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    //...........................................Method to delete Product.........................................
    public boolean deleteProduct(String productName, String supplierName) {
        ArrayList<Product> productList = new ArrayList<>();
        boolean productFound = false;

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("ProductStore.txt"))) {
            try {
                while (true) {
                    ArrayList<Product> tempProductList = (ArrayList<Product>) ois.readObject();
                    for (Product product : tempProductList) {
                        if (product.getProductName().equalsIgnoreCase(productName) && product.getSupplier().getName().equalsIgnoreCase(supplierName)) {
                            productFound = true;
                        } else {
                            productList.add(product);
                        }
                    }
                }
            } catch (EOFException e) {
                // No more objects in the file, so continue execution
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return false; // Return false if an exception occurred
        } catch (Exception e) {
            e.printStackTrace();
            return false; // Return false if an exception occurred
        }

        // Write the updated list to the file if the product was found and removed
        if (productFound) {
            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("ProductStore.txt"))) {
                oos.writeObject(productList);
                return true; // Return true if the data was updated successfully
            } catch (IOException e) {
                e.printStackTrace();
                return false; // Return false if an exception occurred
            }
        } else {
            return false; // Return false if the product was not found
        }
    }



    //...........................................Method to Add Existing Product...................................
    public boolean addExistingProduct(String name, double oldPrice, int quantityAdded, double newPrice) {
        ArrayList<Product> products = new ArrayList<>();

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("ProductStore.txt"))) {
            try {
                while (true) {
                    ArrayList<Product> productList = (ArrayList<Product>) ois.readObject();
                    for (Product product : productList) {
                        if (product.getProductName().equalsIgnoreCase(name) && product.getProductPrice() == oldPrice) {
                            product.setQuantity(product.getQuantityInStock() + quantityAdded);
                            product.setProductPrice(newPrice);
                            break; // Exit the loop after updating the quantity and price
                        }
                        else
                        {
                            return false;
                        }
                    }
                    products.addAll(productList);
                }
            } catch (EOFException e) {
                // No more objects in the file, so continue execution
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return false; // Return false if an exception occurred
        } catch (Exception e) {
            e.printStackTrace();
            return false; // Return false if an exception occurred
        }

        // Write the updated list to the file
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("ProductStore.txt"))) {
            oos.writeObject(products);
            return true; // Return true if the record was updated successfully
        } catch (IOException e) {
            e.printStackTrace();
            return false; // Return false if an exception occurred
        }
    }


    //.............................................Method to Show SalesPersons....................................
    public ArrayList<SalesPerson> showSalesPerson() {
        ArrayList<SalesPerson> salesPersons = new ArrayList<>();
        try {
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream("SalesPersonRecord.txt"));
            try {
                while (true) {
                    ArrayList<SalesPerson> salesPersonData = (ArrayList<SalesPerson>) ois.readObject();
                    salesPersons.addAll(salesPersonData);
                }
            } catch (EOFException e) {
                // No more objects in the file, so continue execution
            }
            ois.close();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return salesPersons;
    }

    //............................................Method to Add SalesPersons...........................................
    public boolean addSalesPerson(SalesPerson salesPerson) {
        ArrayList<SalesPerson> salesPersons = new ArrayList<>();

        // Read existing SalesPersons from file (if any)
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("SalesPersonRecord.txt"))) {
            salesPersons = (ArrayList<SalesPerson>) ois.readObject();
        } catch (EOFException e) {
            // Handle the case where the file is empty
            salesPersons = new ArrayList<>();
        } catch (Exception e) {
            e.printStackTrace();
            return false; // Return false if an exception occurred
        }

        // Append new SalesPerson to the existing list
        salesPersons.add(salesPerson);

        // Write the updated list to the file
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("SalesPersonRecord.txt"))) {
            oos.writeObject(salesPersons);
            return true; // Return true if the process is completed successfully
        } catch (IOException e) {
            e.printStackTrace();
            return false; // Return false if an exception occurred
        }
    }

    //........................................Method to Delete SalesPerson........................................
    public boolean deleteSalesPerson(String name, String email) {
        ArrayList<SalesPerson> salesPersonList = new ArrayList<>();
        boolean salesPersonFound = false;

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("SalesPersonRecord.txt"))) {
            try {
                salesPersonFound = false;
                while (true) {
                    ArrayList<SalesPerson> tempSalesPersonList = (ArrayList<SalesPerson>) ois.readObject();
                    for (SalesPerson salesPerson : tempSalesPersonList) {
                        if (salesPerson.getName().equalsIgnoreCase(name) && salesPerson.getEmail().equalsIgnoreCase(email)) {
                            salesPersonFound = true;
                        } else {
                            salesPersonList.add(salesPerson);
                        }
                    }
                }
            } catch (EOFException e) {
                // No more objects in the file, so continue execution
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return false; // Return false if an exception occurred
        } catch (Exception e) {
            e.printStackTrace();
            return false; // Return false if an exception occurred
        }

        // Write the updated list to the file if the salesperson was found and removed
        if (salesPersonFound) {
            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("SalesPersonRecord.txt"))) {
                oos.writeObject(salesPersonList);
                return true; // Return true if the salesperson was deleted successfully
            } catch (IOException e) {
                e.printStackTrace();
                return false; // Return false if an exception occurred
            }
        } else {
            return false; // Return false if the salesperson was not found
        }
    }

    //...........................................Method to Show SalesRecord.......................................
    public ArrayList<String> showSalesRecord() {
        ArrayList<String> salesRecordDetailsList = new ArrayList<>();
        ArrayList<Receipt> salesRecord;
        try {
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream("SalesRecord.txt"));

            try {
                while (true) {
                    salesRecord = (ArrayList<Receipt>) ois.readObject();
                    if (salesRecord.isEmpty()) {
                        salesRecordDetailsList.add("No data in Record.");
                    } else {
                        for (Receipt record : salesRecord) {
                            // Create a separate ArrayList to store the sales record details
                            ArrayList<String> salesRecordDetails = new ArrayList<>();
                            salesRecordDetails.add("ID: " + record.receiptId);
                            salesRecordDetails.add("Date: " + "  (" + record.getReceiptDate() + ")");
                            salesRecordDetails.add("Customer: " + record.getCustomer().getName());
                            for (Product purchased : record.getCart()) {
                                salesRecordDetails.add("Products: " + purchased.getProductName() + "-" + purchased.getQuantityInStock());
                            }
                            salesRecordDetails.add("Total Bill: " + record.getAmount());
                            salesRecordDetails.add("SalesPerson: " + record.getSalesOfficer().getName());
                            salesRecordDetails.add("....................................................");

                            // Add the sales record details ArrayList to the main list
                            salesRecordDetailsList.addAll(salesRecordDetails);
                        }
                    }
                }
            } catch (EOFException e) {
                // No more objects in the file, so continue execution
            }

            ois.close();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return salesRecordDetailsList;
    }


    //............................................Method to Delete SalesRecord....................................
    public boolean deleteSalesRecord() {
        try {
            // Open the file in write mode
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("SalesRecord.txt"));

            // Write an empty ArrayList to clear the file
            ArrayList<Receipt> emptySalesRecord = new ArrayList<>();
            oos.writeObject(emptySalesRecord);
            oos.close();
            return true; // Return true indicating successful deletion
        } catch (IOException e) {
            e.printStackTrace();
            return false; // Return false indicating failure
        }
    }


    //............................................Method to Show Account Details..................................

//        Owner o = new Owner("Wajahat","0331-0207494","wajahat@gmail.com","wajahat1214",1000,19000);
//        try
//        {
//            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("OwnerRecord.txt"));
//            oos.writeObject(o);
//            oos.close();
//        }
//        catch(Exception e)
//        {
//            System.out.println("Error");
//        }
    public static Owner displayAccount()
    {
        Owner owner = null;

        try
        {
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream("OwnerRecord.txt"));
        owner = (Owner) ois.readObject();
        ois.close();
        }
        catch (IOException | ClassNotFoundException e)
        {
        System.out.println(e);
         }

        return owner;
    }


    @Override
    public String toString() {
        String displayString = "Owner's " + super.toString() +
                "\nPassword: " + getPassword() + "\n" +
                "Account Balance: " + getAccBalance() + "\n" +
                "Revenue Generated: " + getTotalRevenue() + "\n";
        return displayString;
    }

}
