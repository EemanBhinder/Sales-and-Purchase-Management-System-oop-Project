import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.io.*;
import java.util.ArrayList;

public class Receipt implements Serializable
{
    private static final long serialVersionUID = 5018065893772484716L;

    protected int receiptId;
    protected String date;
    protected ArrayList<Product> cart ;
    protected double amount;
    protected String paymentMethod;
    protected static SalesPerson salesOfficer;
    protected Customer customer;

    public Receipt()
    {
        receiptId = (int) (Math.random()*1000);
        LocalDate currentDate = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        String dateString = currentDate.format(formatter);
        date = dateString;
        cart = null;
        amount = 0;
        paymentMethod = "NULL";
    }
    public Receipt(int receiptId, String date, ArrayList<Product> products, double amount, String paymentMethod,Customer customer,SalesPerson salesperson)
    {
        this.receiptId = receiptId;
        this.date = date;
        this.cart = products;
        this.amount = amount;
        this.paymentMethod = paymentMethod;
        this.customer = customer;
        this.salesOfficer = salesperson;
    }

    // Getters and Setters

    public void setCart(ArrayList<Product> cart)
    {
        this.cart = cart;
    }

    public void setSalesOfficer(SalesPerson salesOfficer)
    {
        this.salesOfficer = salesOfficer;
    }
    public void setPaymentMethod(String paymentMethod)
    {
        this.paymentMethod = paymentMethod;
    }

    public ArrayList<Product> getCart()
    {
        return cart;
    }

    public int getReceiptId()
    {
        return receiptId;
    }
    public String getReceiptDate()
    {
        return date;
    }
    public double getAmount()
    {
        return amount;
    }
    public String getPaymentMethod()
    {
        return paymentMethod;
    }
    public SalesPerson getSalesOfficer()
    {
        return salesOfficer;
    }
    public Customer getCustomer()
    {
        return customer;
    }

    public String toString() {
        String value = "";
        Store store = new Store();
        value += "\n\n......." + store.getStoreName() + ".......";
        value += "\n......(" + store.getStoreAddress() + ")......";
        value += "\nReceipt ID: " + receiptId;
        value += "\nReceipt Date: " + date;
        value += "\nProducts:";
        int i = 0;
        for (int j = 0; j < cart.size(); j++) {
            value += "\n" + (j+1)  + " - " + cart.get(j).getProductName() + "\n   Quantity: " + cart.get(j).getQuantityInStock() + "\n   Price Per Piece: " + cart.get(j).getProductPrice() + "\n   Amount: " + cart.get(j).getQuantityInStock() * cart.get(j).getProductPrice();
        }
        value += "\nTotal Amount: " + amount;
        value += "\nPayment Method: " + paymentMethod;
        value += "\nSalesPerson: " + salesOfficer.getName();
        return value;
    }
}
