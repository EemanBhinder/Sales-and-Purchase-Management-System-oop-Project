public interface LoginInterface
{
    boolean login(String email, String password);
    boolean updateLogin(String existingEmail, String existingPassword,String newMail,String newPassword);
}
