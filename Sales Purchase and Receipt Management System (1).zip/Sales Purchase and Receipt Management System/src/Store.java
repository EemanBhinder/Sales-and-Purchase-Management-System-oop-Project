import java.util.*;
import java.io.*;
public class Store implements Serializable
{
    protected static String storeName;
    protected static String storeAddress;
    protected static Product [] productStock;
    protected static SalesPerson [] salesOfficer;

    public Store()
    {
        storeName = "MEDICS PHARMACY";
        storeAddress = "Islamabad Pakistan";
        productStock = new Product[0];
        salesOfficer = new SalesPerson[0];
    }
    public Store(String storeName, String storeAddress, Product [] productStock,SalesPerson[] salesOfficer)
    {
        this.storeName = storeName;
        this.storeAddress = storeAddress;
        this.productStock = productStock;
        this.salesOfficer = salesOfficer;
    }
    public void setStoreName(String storeName)
    {
        Store.storeName = storeName;
    }
    public void setStoreAddress(String storeAddress)
    {
        Store.storeAddress = storeAddress;
    }
    public void setProductStock(Product[] productStock)
    {
        Store.productStock = productStock;
    }
    public void setSalesOfficer(SalesPerson[] salesOfficer)
    {
        Store.salesOfficer = salesOfficer;
    }

    public static String getStoreName()
    {
        return storeName;
    }
    public static String getStoreAddress()
    {
        return storeAddress;
    }
    public static Product[] getProductStock()
    {
        return productStock;
    }

    public static SalesPerson[] getSalesOfficer()
    {
        return salesOfficer;
    }
    public static void addSalesPerson()//.............Method to Add SalesPerson....................
    {
        Scanner input = new Scanner(System.in);
        System.out.println("\n\n.............Entering new SalesPerson in Store...........");
        System.out.print("Enter SalesPerson Name: ");
        String name = input.nextLine();
        System.out.print("Enter SalesPerson Phone: ");
        String phone = input.nextLine();
        System.out.print("Enter SalesPerson Email: ");
        String email = input.nextLine();
        System.out.print("Enter SalesPerson ID: ");
        String id = input.nextLine();
        System.out.print("Enter SalesPerson Password: ");
        String password = input.nextLine();
        SalesPerson p3 = new SalesPerson(name, phone, email, id,password);

        SalesPerson [] existingStock = salesOfficer;
        SalesPerson [] currentStock = new SalesPerson[existingStock.length + 1];

        for (int i = 0; i < existingStock.length; i++)
        {
            currentStock[i] = existingStock[i];
        }
        currentStock[currentStock.length - 1] = p3;
        Store store = new Store("Hamd Pharmacy", "Islamabad", productStock,currentStock);
    }

    public static void displaySalesPersons()//.......Method to Display Available SalesPersons......
    {
        System.out.println("\n.................Sales Persons in Store....................");
        for(int i = 0; i < salesOfficer.length ; i++ )
        {
            System.out.println("\n.......SalesPerson " + (i+1) + " ........");
            System.out.println("SalesPerson Name: " + salesOfficer[i].getName());
            System.out.println("SalesPerson ID: " + salesOfficer[i].getID());
        }
    }
}


