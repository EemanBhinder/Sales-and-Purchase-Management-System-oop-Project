import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Scanner;

public class SalesPersonGUI extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;

    SalesPersonGUI() {
        this.setVisible(true);
        this.setSize(400, 200);
        this.setTitle("SalesPerson Login");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.setLayout(new BorderLayout());

        ImageIcon logo = new ImageIcon("Logo.png");
        this.setIconImage(logo.getImage());


        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 2, 10, 10));

        JLabel appNameLabel = new JLabel("My Application");
        appNameLabel.setFont(new Font("Arial", Font.BOLD, 18));
        appNameLabel.setHorizontalAlignment(SwingConstants.CENTER);

        JLabel nameLabel = new JLabel("Enter Email:");
        usernameField = new JTextField();

        JLabel passwordLabel = new JLabel("Enter Password:");
        passwordField = new JPasswordField();

        JButton loginButton = new JButton("Login");
        JButton mainMenuButton = new JButton("Main Menu");

        // Styling options
        Font buttonFont = new Font("Arial", Font.BOLD, 14);
        Color buttonColor = new Color(0, 128, 0);

        appNameLabel.setForeground(buttonColor);
        mainMenuButton.setFont(buttonFont);

        mainMenuButton.setBackground(buttonColor);
        mainMenuButton.setForeground(Color.WHITE);

        // Main Menu button action listener
        mainMenuButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose(); // Close the login window
                MainFrame mainFrame = new MainFrame(); // Open the main menu window
            }
        });

        // Login button action listener
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                SalesPerson salesPerson = new SalesPerson();
                boolean loginSuccessful = salesPerson.login(username, password);
                if (loginSuccessful) {
                    dispose(); // Close the login window
                    showOwnerOptions(); // Open the owner options window
                } else {
                    JOptionPane.showMessageDialog(SalesPersonGUI.this, "Invalid username or password. Please try again.", "Login Failed", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        panel.add(appNameLabel);
        panel.add(new JLabel()); // Empty label for spacing
        panel.add(nameLabel);
        panel.add(usernameField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(loginButton);
        panel.add(mainMenuButton);

        add(panel, BorderLayout.CENTER);
        pack();
        setLocationRelativeTo(null);
    }

    private void showOwnerOptions() {
        JFrame optionsFrame = new JFrame();
        optionsFrame.setTitle("SalesPerson Options");
        optionsFrame.setSize(900, 400);
        optionsFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        optionsFrame.setLayout(new BorderLayout());

        JPanel optionsPanel = new JPanel();
        optionsPanel.setLayout(new GridLayout(4, 2, 10, 10));
        optionsPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JButton updateLoginButton = new JButton("Update Login");
        JButton displayProductStockButton = new JButton("Display Product Stock");
        JButton startOrder = new JButton("Start Order");
        JButton logoutButton = new JButton("Logout");

        // Styling options
        Font buttonFont = new Font("Arial", Font.BOLD, 18);
        Color buttonColor = new Color(0, 128, 0);

        JButton[] buttons = {
                updateLoginButton,
                displayProductStockButton,
                startOrder,
                logoutButton
        };

        FontMetrics fontMetrics = updateLoginButton.getFontMetrics(buttonFont);
        int maxButtonWidth = 0;

        for (JButton button : buttons) {
            int buttonWidth = fontMetrics.stringWidth(button.getText());
            maxButtonWidth = Math.max(maxButtonWidth, buttonWidth);
            button.setFont(buttonFont);
            button.setBackground(buttonColor);
            button.setForeground(Color.WHITE);
        }

        Dimension buttonSize = new Dimension(maxButtonWidth + 20, 40);

        for (JButton button : buttons) {
            button.setPreferredSize(buttonSize);
            optionsPanel.add(button);
        }

        updateLoginButton.setBackground(buttonColor);
        displayProductStockButton.setBackground(buttonColor);
        startOrder.setBackground(buttonColor);
        logoutButton.setBackground(Color.black);

        updateLoginButton.setForeground(Color.WHITE);
        displayProductStockButton.setForeground(Color.WHITE);
        startOrder.setForeground(Color.WHITE);
        logoutButton.setForeground(Color.WHITE);


        //UpdateLogin Action Listener.........................................................
        updateLoginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                while (true) {
                    JPanel updatePanel = new JPanel();
                    updatePanel.setLayout(new GridLayout(4, 2, 10, 10));

                    JLabel existingEmailLabel = new JLabel("Existing Email:");
                    JTextField existingEmailField = new JTextField();

                    JLabel existingPasswordLabel = new JLabel("Existing Password:");
                    JPasswordField existingPasswordField = new JPasswordField();

                    JLabel newEmailLabel = new JLabel("New Email:");
                    JTextField newEmailField = new JTextField();

                    JLabel newPasswordLabel = new JLabel("New Password:");
                    JPasswordField newPasswordField = new JPasswordField();

                    updatePanel.add(existingEmailLabel);
                    updatePanel.add(existingEmailField);
                    updatePanel.add(existingPasswordLabel);
                    updatePanel.add(existingPasswordField);
                    updatePanel.add(newEmailLabel);
                    updatePanel.add(newEmailField);
                    updatePanel.add(newPasswordLabel);
                    updatePanel.add(newPasswordField);

                    int result = JOptionPane.showConfirmDialog(SalesPersonGUI.this, updatePanel, "Update Login",
                            JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

                    if (result == JOptionPane.OK_OPTION) {
                        String existingEmail = existingEmailField.getText();
                        String existingPassword = new String(existingPasswordField.getPassword());
                        String newEmail = newEmailField.getText();
                        String newPassword = new String(newPasswordField.getPassword());

                        String verifiedExistingEmail = Utility.verifyEmail(existingEmail);
                        String verifiedNewEmail = Utility.verifyEmail(newEmail);

                        if (verifiedExistingEmail.equalsIgnoreCase("NULL") || verifiedNewEmail.equalsIgnoreCase("NULL")) {
                            JOptionPane.showMessageDialog(SalesPersonGUI.this, "Invalid email format. Please enter a valid email.", "Error", JOptionPane.ERROR_MESSAGE);
                            continue; // Restart the loop to get input again
                        }

                        SalesPerson salesPerson = new SalesPerson();
                        boolean updateSuccessful = salesPerson.updateLogin(verifiedExistingEmail, existingPassword, verifiedNewEmail, newPassword);

                        if (updateSuccessful) {
                            JOptionPane.showMessageDialog(SalesPersonGUI.this, "Update successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            JOptionPane.showMessageDialog(SalesPersonGUI.this, "Failed to update.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                        break; // Exit the loop after successful update
                    } else {
                        break; // Exit the loop if cancel is clicked
                    }
                }
            }
        });

        // Display Product Stock Action Listener........................................................
        displayProductStockButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ArrayList<Product> products = Utility.showProductStock();
                if (products.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "No products available.");
                } else {
                    StringBuilder stockText = new StringBuilder();
                    for (Product product : products) {
                        stockText.append(product.display()).append("\n\n");
                    }
                    showProductStockWindow(stockText.toString());
                }
            }

            // Method to display product stock in a new window
            public void showProductStockWindow(String stockText) {
                JFrame frame = new JFrame("Product Stock");
                JTextArea stockTextArea = new JTextArea(stockText);
                stockTextArea.setEditable(false);
                JScrollPane scrollPane = new JScrollPane(stockTextArea);
                frame.getContentPane().add(scrollPane);
                frame.setSize(400, 300);
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);
            }
        });



// ActionListener for the "Start Order" button
        startOrder.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ArrayList<Product> selectedProductsList = new ArrayList<>(); // Create an ArrayList to store selected products

                // Create a separate window to input customer details and product information
                JFrame customerDetailsWindow = new JFrame("Customer Details");
                customerDetailsWindow.setSize(500, 900);
                customerDetailsWindow.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                customerDetailsWindow.setLayout(new GridBagLayout());

                // Create a GridBagConstraints object for consistent component placement
                GridBagConstraints gbc = new GridBagConstraints();
                gbc.gridx = 0;
                gbc.gridy = 0;
                gbc.insets = new Insets(5, 5, 5, 5); // Add spacing between components

                // Create labels and text fields for customer details
                customerDetailsWindow.add(new JLabel("Customer Name:"), gbc);
                gbc.gridx++;
                JTextField nameField = new JTextField();
                nameField.setPreferredSize(new Dimension(200, 30)); // Set preferred size for text field
                customerDetailsWindow.add(nameField, gbc);

                gbc.gridx = 0;
                gbc.gridy++;
                customerDetailsWindow.add(new JLabel("Customer Phone:"), gbc);
                gbc.gridx++;
                JTextField phoneField = new JTextField();
                phoneField.setPreferredSize(new Dimension(200, 30)); // Set preferred size for text field
                customerDetailsWindow.add(phoneField, gbc);

                gbc.gridx = 0;
                gbc.gridy++;
                customerDetailsWindow.add(new JLabel("Customer Email:"), gbc);
                gbc.gridx++;
                JTextField emailField = new JTextField();
                emailField.setPreferredSize(new Dimension(200, 30)); // Set preferred size for text field
                customerDetailsWindow.add(emailField, gbc);

                gbc.gridx = 0;
                gbc.gridy++;
                customerDetailsWindow.add(new JLabel("Customer ID:"), gbc);
                gbc.gridx++;
                JTextField idField = new JTextField();
                idField.setPreferredSize(new Dimension(200, 30)); // Set preferred size for text field
                customerDetailsWindow.add(idField, gbc);

                gbc.gridx = 0;
                gbc.gridy++;
                customerDetailsWindow.add(new JLabel("Payment Method:"), gbc);
                gbc.gridx++;
                JTextField paymentField = new JTextField();
                paymentField.setPreferredSize(new Dimension(200, 30)); // Set preferred size for text field
                customerDetailsWindow.add(paymentField, gbc);

                // Create labels and text fields for product information
                gbc.gridx = 0;
                gbc.gridy++;
                customerDetailsWindow.add(new JLabel("Product Name"), gbc);
                gbc.gridx++;
                customerDetailsWindow.add(new JLabel("Quantity"), gbc);

                JTextField[] productFields = new JTextField[10];
                JTextField[] quantityFields = new JTextField[10];

                for (int i = 0; i < 10; i++) {
                    gbc.gridx = 0;
                    gbc.gridy++;
                    productFields[i] = new JTextField();
                    productFields[i].setPreferredSize(new Dimension(200, 30)); // Set preferred size for text field
                    customerDetailsWindow.add(productFields[i], gbc);
                    gbc.gridx++;
                    quantityFields[i] = new JTextField();
                    quantityFields[i].setPreferredSize(new Dimension(200, 30)); // Set preferred size for text field
                    customerDetailsWindow.add(quantityFields[i], gbc);
                }

                // Create confirm button
                gbc.gridx = 0;
                gbc.gridy++;
                gbc.gridwidth = 2; // Span the button across two columns
                gbc.anchor = GridBagConstraints.CENTER; // Center-align the button

                JButton confirmButton = new JButton("Confirm");
                customerDetailsWindow.add(confirmButton, gbc);

                // Set action listener for the confirm button
                confirmButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        // Get customer details from the text fields
                        String name = nameField.getText();
                        String phone = phoneField.getText();
                        String email = emailField.getText();
                        String id = idField.getText();
                        String paymentMethod = paymentField.getText();

                        // Get product information from the text fields and create Product objects
                        ArrayList<Product> selectedProductsList = new ArrayList<>();
                        for (int i = 0; i < 10; i++) {
                            String productName = productFields[i].getText();
                            String quantityText = quantityFields[i].getText();

                            // Check if both the product name and quantity are empty
                            if (productName.isEmpty() && quantityText.isEmpty()) {
                                break; // Stop processing if both fields are empty
                            }

                            // Check if the quantity field is empty or not a valid number
                            if (productName.isEmpty() || quantityText.isEmpty()) {
                                JOptionPane.showMessageDialog(null, "Please fill in all product information.", "Error", JOptionPane.ERROR_MESSAGE);
                                return; // Stop further processing
                            }

                            int quantity;
                            try {
                                quantity = Integer.parseInt(quantityText);
                            } catch (NumberFormatException ex) {
                                JOptionPane.showMessageDialog(null, "Invalid quantity for product: " + productName, "Error", JOptionPane.ERROR_MESSAGE);
                                return; // Stop further processing
                            }

                            Product product = new Product();
                            product.setProductName(productName);
                            product.setQuantity(quantity);
                            selectedProductsList.add(product);
                        }

                        // Perform the purchase
                        SalesPerson salesPerson = new SalesPerson();
                        Receipt receipt = salesPerson.startPurchase(name, phone, email, id, selectedProductsList, paymentMethod);

                        // Display the receipt in a dialog box
                        JOptionPane.showMessageDialog(null, receipt.toString(), "Receipt", JOptionPane.INFORMATION_MESSAGE);

                        // Clear the selected products list
                        selectedProductsList.clear();

                        // Close the customer details window
                        customerDetailsWindow.dispose();
                    }
                });

                // Make the customer details window visible
                customerDetailsWindow.setVisible(true);
            }
        });



        // Logout button action listener......................................................
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                optionsFrame.dispose(); // Close the options window
                OwnerGUI ownerGUI = new OwnerGUI(); // Open the login window
            }
        });


        optionsPanel.add(updateLoginButton);
        optionsPanel.add(startOrder);
        optionsPanel.add(displayProductStockButton);
        optionsPanel.add(logoutButton);



        optionsFrame.add(optionsPanel, BorderLayout.CENTER);
        optionsFrame.setLocationRelativeTo(null);
        optionsFrame.setVisible(true);
    }
}