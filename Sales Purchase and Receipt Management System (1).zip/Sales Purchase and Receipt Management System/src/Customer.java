import java.io.Serializable;

import java.io.*;
class Customer extends Person implements Serializable
{
    private String custId;

    //Non parametrized constructor
    public Customer()
    {
        super();
        custId = "0000";
    }
    //Parametrized constructor
    public Customer(String name, String phone, String email,String id)
    {
        super(name, phone, email);
        this.custId = id;
    }
    public void setCust_Id(String cust_Id)
    {
        this.custId = custId;
    }
    public String getCust_Id()
    {
        return custId;
    }

    @Override
    public String toString() {
        String displayString = "Customer ID: " + custId + "\n" +
                "Customer's " + super.toString();
        return displayString;
    }

}
