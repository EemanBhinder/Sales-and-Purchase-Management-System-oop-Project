import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Scanner;

public class OwnerGUI extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;

    OwnerGUI() {
        this.setVisible(true);
        this.setSize(400, 200);
        this.setTitle("Owner Login");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.setLayout(new BorderLayout());

        ImageIcon logo = new ImageIcon("Logo.png");
        this.setIconImage(logo.getImage());


        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 2, 10, 10));

        JLabel appNameLabel = new JLabel("My Application");
        appNameLabel.setFont(new Font("Arial", Font.BOLD, 18));
        appNameLabel.setHorizontalAlignment(SwingConstants.CENTER);

        JLabel nameLabel = new JLabel("Enter Email:");
        usernameField = new JTextField();

        JLabel passwordLabel = new JLabel("Enter Password:");
        passwordField = new JPasswordField();

        JButton loginButton = new JButton("Login");
        JButton mainMenuButton = new JButton("Main Menu");

        // Styling options
        Font buttonFont = new Font("Arial", Font.BOLD, 14);
        Color buttonColor = new Color(0, 128, 0);

        appNameLabel.setForeground(buttonColor);
        mainMenuButton.setFont(buttonFont);

        mainMenuButton.setBackground(buttonColor);
        mainMenuButton.setForeground(Color.WHITE);

        // Main Menu button action listener
        mainMenuButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose(); // Close the login window
                MainFrame mainFrame = new MainFrame(); // Open the main menu window
            }
        });

        // Login button action listener
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                Owner owner = new Owner();
                boolean loginSuccessful = owner.login(username, password);
                if (loginSuccessful) {
                    dispose(); // Close the login window
                    showOwnerOptions(); // Open the owner options window
                } else {
                    JOptionPane.showMessageDialog(OwnerGUI.this, "Invalid username or password. Please try again.", "Login Failed", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        panel.add(appNameLabel);
        panel.add(new JLabel()); // Empty label for spacing
        panel.add(nameLabel);
        panel.add(usernameField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(loginButton);
        panel.add(mainMenuButton);

        add(panel, BorderLayout.CENTER);
        pack();
        setLocationRelativeTo(null);
    }

    private void showOwnerOptions() {
        JFrame optionsFrame = new JFrame();
        optionsFrame.setTitle("Owner Options");
        optionsFrame.setSize(900, 400);
        optionsFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        optionsFrame.setLayout(new BorderLayout());

        JPanel optionsPanel = new JPanel();
        optionsPanel.setLayout(new GridLayout(4, 2, 10, 10));
        optionsPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JButton showProfileButton = new JButton("Show Profile");
        JButton updateLoginButton = new JButton("Update Login");
        JButton displayProductStockButton = new JButton("Display Product Stock");
        JButton addNewProductButton = new JButton("Add New Product");
        JButton addExistingProductButton = new JButton("Add Existing Product");
        JButton deleteProductButton = new JButton("Delete Product");
        JButton displaySalesPersonsButton = new JButton("Display SalesPersons");
        JButton addSalesPersonButton = new JButton("Add SalesPerson");
        JButton deleteSalesPersonButton = new JButton("Delete SalesPerson");
        JButton showSalesRecordButton = new JButton("Show Sales Record");
        JButton clearSalesRecordButton = new JButton("Clear Sales Record");
        JButton updateAccountButton = new JButton("Update Balance");
        JButton logoutButton = new JButton("Logout");

        // Styling options
        Font buttonFont = new Font("Arial", Font.BOLD, 14);
        Color buttonColor = new Color(0, 128, 0);

        JButton[] buttons = {
                showProfileButton,
                updateLoginButton,
                displayProductStockButton,
                addNewProductButton,
                addExistingProductButton,
                deleteProductButton,
                displaySalesPersonsButton,
                addSalesPersonButton,
                deleteSalesPersonButton,
                showSalesRecordButton,
                clearSalesRecordButton,
                updateAccountButton,
                logoutButton
        };

        FontMetrics fontMetrics = updateLoginButton.getFontMetrics(buttonFont);
        int maxButtonWidth = 0;

        for (JButton button : buttons) {
            int buttonWidth = fontMetrics.stringWidth(button.getText());
            maxButtonWidth = Math.max(maxButtonWidth, buttonWidth);
            button.setFont(buttonFont);
            button.setBackground(buttonColor);
            button.setForeground(Color.WHITE);
        }

        Dimension buttonSize = new Dimension(maxButtonWidth + 20, 40);

        for (JButton button : buttons) {
            button.setPreferredSize(buttonSize);
            optionsPanel.add(button);
        }
        showProfileButton.setBackground(buttonColor);
        updateLoginButton.setBackground(buttonColor);
        displayProductStockButton.setBackground(buttonColor);
        addNewProductButton.setBackground(buttonColor);
        addExistingProductButton.setBackground(buttonColor);
        deleteProductButton.setBackground(buttonColor);
        displaySalesPersonsButton.setBackground(buttonColor);
        addSalesPersonButton.setBackground(buttonColor);
        deleteSalesPersonButton.setBackground(buttonColor);
        showSalesRecordButton.setBackground(buttonColor);
        clearSalesRecordButton.setBackground(buttonColor);
        updateAccountButton.setBackground(buttonColor);
        logoutButton.setBackground(Color.black);


        showProfileButton.setForeground(Color.WHITE);
        updateLoginButton.setForeground(Color.WHITE);
        displayProductStockButton.setForeground(Color.WHITE);
        addNewProductButton.setForeground(Color.WHITE);
        addExistingProductButton.setForeground(Color.WHITE);
        deleteProductButton.setForeground(Color.WHITE);
        displaySalesPersonsButton.setForeground(Color.WHITE);
        addSalesPersonButton.setForeground(Color.WHITE);
        deleteSalesPersonButton.setForeground(Color.WHITE);
        showSalesRecordButton.setForeground(Color.WHITE);
        clearSalesRecordButton.setForeground(Color.WHITE);
        updateAccountButton.setForeground(Color.WHITE);
        logoutButton.setForeground(Color.WHITE);

        //Show Profile Action Listener........................................................
        showProfileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Owner o1 = new Owner();
                Owner owner = o1.displayAccount();
                if (owner != null) {
                    // Create a new window to display the account details
                    JFrame profileFrame = new JFrame("Owner Profile");
                    profileFrame.setSize(400, 300);
                    profileFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

                    // Create a text area to display the account details
                    JTextArea profileTextArea = new JTextArea(owner.toString());
                    profileTextArea.setEditable(false);
                    JScrollPane scrollPane = new JScrollPane(profileTextArea);

                    // Add the text area to the frame
                    profileFrame.add(scrollPane);

                    // Set the frame visible
                    profileFrame.setLocationRelativeTo(null);
                    profileFrame.setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(OwnerGUI.this, "Failed to retrieve account details.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });


        //UpdateLogin Action Listener.........................................................
        updateLoginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                while (true) {
                    JPanel updatePanel = new JPanel();
                    updatePanel.setLayout(new GridLayout(4, 2, 10, 10));

                    JLabel existingEmailLabel = new JLabel("Existing Email:");
                    JTextField existingEmailField = new JTextField();

                    JLabel existingPasswordLabel = new JLabel("Existing Password:");
                    JPasswordField existingPasswordField = new JPasswordField();

                    JLabel newEmailLabel = new JLabel("New Email:");
                    JTextField newEmailField = new JTextField();

                    JLabel newPasswordLabel = new JLabel("New Password:");
                    JPasswordField newPasswordField = new JPasswordField();

                    updatePanel.add(existingEmailLabel);
                    updatePanel.add(existingEmailField);
                    updatePanel.add(existingPasswordLabel);
                    updatePanel.add(existingPasswordField);
                    updatePanel.add(newEmailLabel);
                    updatePanel.add(newEmailField);
                    updatePanel.add(newPasswordLabel);
                    updatePanel.add(newPasswordField);

                    int result = JOptionPane.showConfirmDialog(OwnerGUI.this, updatePanel, "Update Login",
                            JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

                    if (result == JOptionPane.OK_OPTION) {
                        String existingEmail = existingEmailField.getText();
                        String existingPassword = new String(existingPasswordField.getPassword());
                        String newEmail = newEmailField.getText();
                        String newPassword = new String(newPasswordField.getPassword());

                        String verifiedExistingEmail = Utility.verifyEmail(existingEmail);
                        String verifiedNewEmail = Utility.verifyEmail(newEmail);

                        if (verifiedExistingEmail.equalsIgnoreCase("NULL") || verifiedNewEmail.equalsIgnoreCase("NULL")) {
                            JOptionPane.showMessageDialog(OwnerGUI.this, "Invalid email format. Please enter a valid email.", "Error", JOptionPane.ERROR_MESSAGE);
                            continue; // Restart the loop to get input again
                        }

                        Owner owner = new Owner();
                        boolean updateSuccessful = owner.updateLogin(verifiedExistingEmail, existingPassword, verifiedNewEmail, newPassword);

                        if (updateSuccessful) {
                            JOptionPane.showMessageDialog(OwnerGUI.this, "Update successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            JOptionPane.showMessageDialog(OwnerGUI.this, "Failed to update.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                        break; // Exit the loop after successful update
                    } else {
                        break; // Exit the loop if cancel is clicked
                    }
                }
            }
        });

        // Display Product Stock Action Listener........................................................
        displayProductStockButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                ArrayList<Product> products = Utility.showProductStock();
                if (products.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "No products available.");
                } else {
                    StringBuilder stockText = new StringBuilder();
                    for (Product product : products) {
                        stockText.append(product.display()).append("\n\n");
                    }
                    showProductStockWindow(stockText.toString());
                }
            }

            // Method to display product stock in a new window
            public void showProductStockWindow(String stockText) {
                JFrame frame = new JFrame("Product Stock");
                JTextArea stockTextArea = new JTextArea(stockText);
                stockTextArea.setEditable(false);
                JScrollPane scrollPane = new JScrollPane(stockTextArea);
                frame.getContentPane().add(scrollPane);
                frame.setSize(400, 300);
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);
            }
        });



        // Add New Product Action Listener.............................................................
        addNewProductButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Create a new window for input
                JFrame inputFrame = new JFrame("Enter Product Details");
                inputFrame.setSize(520,520);
                inputFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

                // Create input fields and labels
                JTextField nameField = new JTextField();
                JTextField priceField = new JTextField();
                JTextField quantityField = new JTextField();
                JTextField weightField = new JTextField();
                JTextField descriptionField = new JTextField();
                JTextField supplierNameField = new JTextField();
                JTextField idField = new JTextField();
                JTextField phoneField = new JTextField();
                JTextField emailField = new JTextField();

                // Create a button for submitting the input
                JButton submitButton = new JButton("Add Product");
                submitButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        // Retrieve the input values
                        String name = nameField.getText();
                        double price = Double.parseDouble(priceField.getText());
                        int quantity = Integer.parseInt(quantityField.getText());
                        double weight = Double.parseDouble(weightField.getText());
                        String description = descriptionField.getText();
                        String supplierName = supplierNameField.getText();
                        String id = idField.getText();
                        String phone = phoneField.getText();
                        String email = emailField.getText();

                        // Verify name, phone, and email
                        String nameError = Utility.verifyName(name);
                        String phoneError = Utility.verifyPhone(phone);
                        String emailError = Utility.verifyEmail(email);

                        if (nameError.equalsIgnoreCase("NULL") || phoneError.equalsIgnoreCase("NULL") || emailError.equalsIgnoreCase("NULL")) {
                            // Display error message in a separate window
                            JFrame errorFrame = new JFrame("Error");
                            JOptionPane.showMessageDialog(errorFrame, "Please enter correct information. Verification failed.");
                        } else {
                            // Create a new supplier and product
                            Supplier supplier = new Supplier(supplierName, phone, email, id);
                            Product newProduct = new Product(name, price, quantity, weight, description, supplier);
                            Owner owner = new Owner();

                            // Call the modified method to add the new product
                            owner.addNewProduct(newProduct);

                            // Display success message in a separate window
                            JFrame successFrame = new JFrame("Success");
                            JOptionPane.showMessageDialog(successFrame, "New product added successfully!");

                            // Close the input window
                            inputFrame.dispose();
                        }
                    }
                });

                // Create a layout for the input window
                JPanel inputPanel = new JPanel(new GridLayout(10, 2));
                inputPanel.add(new JLabel("Product Name: "));
                inputPanel.add(nameField);
                inputPanel.add(new JLabel("Product Price: "));
                inputPanel.add(priceField);
                inputPanel.add(new JLabel("Product Quantity: "));
                inputPanel.add(quantityField);
                inputPanel.add(new JLabel("Product Weight: "));
                inputPanel.add(weightField);
                inputPanel.add(new JLabel("Product Description: "));
                inputPanel.add(descriptionField);
                inputPanel.add(new JLabel("Supplier Name: "));
                inputPanel.add(supplierNameField);
                inputPanel.add(new JLabel("Supplier ID: "));
                inputPanel.add(idField);
                inputPanel.add(new JLabel("Supplier Phone: "));
                inputPanel.add(phoneField);
                inputPanel.add(new JLabel("Supplier Email: "));
                inputPanel.add(emailField);
                inputPanel.add(submitButton);

                // Set the layout for the input window
                inputFrame.getContentPane().add(inputPanel);
//                inputFrame.pack();
                inputFrame.setVisible(true);
            }
        });


        // Add Existing Product Action Listener........................................................
        addExistingProductButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Create a new window for input
                JFrame inputFrame = new JFrame("Enter Existing Product Details");
                inputFrame.setSize(520,520);
                inputFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

                // Create input fields and labels
                JTextField nameField = new JTextField();
                JTextField oldPriceField = new JTextField();
                JTextField quantityAddedField = new JTextField();
                JTextField newPriceField = new JTextField();

                // Create a button for submitting the input
                JButton submitButton = new JButton("Modify Product");
                submitButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        // Retrieve the input values
                        String name = nameField.getText();
                        double oldPrice = Double.parseDouble(oldPriceField.getText());
                        int quantityAdded = Integer.parseInt(quantityAddedField.getText());
                        double newPrice = Double.parseDouble(newPriceField.getText());

                        // Call the addExistingProduct method
                        Owner owner = new Owner();
                        boolean success = owner.addExistingProduct(name, oldPrice, quantityAdded, newPrice);

                        // Display error or success dialogue based on the result
                        if (success) {
                            JOptionPane.showMessageDialog(inputFrame, "Product record updated successfully!");
                        } else {
                            JOptionPane.showMessageDialog(inputFrame, "Failed to update product record. Please try again.");
                        }

                        // Close the input window
                        inputFrame.dispose();
                    }
                });

                // Create a panel and add input fields and submit button to it
                JPanel panel = new JPanel();
                panel.setLayout(new GridLayout(5, 2));
                panel.add(new JLabel("Product Name:"));
                panel.add(nameField);
                panel.add(new JLabel("Old Price:"));
                panel.add(oldPriceField);
                panel.add(new JLabel("Quantity Added:"));
                panel.add(quantityAddedField);
                panel.add(new JLabel("New Price:"));
                panel.add(newPriceField);
                panel.add(submitButton);

                // Add the panel to the input frame
                inputFrame.getContentPane().add(panel);
//                inputFrame.pack();
                inputFrame.setVisible(true);
            }
        });

        // Delete Product Action Listener..............................................................
        deleteProductButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Create a new window for input
                JFrame inputFrame = new JFrame("Delete Product");
                inputFrame.setSize(520,520);
                inputFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

                // Create input fields and labels
                JTextField productNameField = new JTextField();
                JTextField supplierNameField = new JTextField();

                // Create a button for submitting the input
                JButton submitButton = new JButton("Delete Product");
                submitButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        // Retrieve the input values
                        String productName = productNameField.getText();
                        String supplierName = supplierNameField.getText();

                        // Call the deleteProduct method
                        Owner owner = new Owner();
                        boolean success = owner.deleteProduct(productName, supplierName);

                        // Display error or success dialogue based on the result
                        if (success) {
                            JOptionPane.showMessageDialog(inputFrame, "Product deleted successfully!");
                        } else {
                            JOptionPane.showMessageDialog(inputFrame, "Failed to delete product. Please check the input values.");
                        }

                        // Close the input window
                        inputFrame.dispose();
                    }
                });

                // Create a panel and add input fields and submit button to it
                JPanel panel = new JPanel();
                panel.setLayout(new GridLayout(3, 2));
                panel.add(new JLabel("Product Name:"));
                panel.add(productNameField);
                panel.add(new JLabel("Supplier Name:"));
                panel.add(supplierNameField);
                panel.add(submitButton);

                // Add the panel to the input frame
                inputFrame.getContentPane().add(panel);
//                inputFrame.pack();
                inputFrame.setVisible(true);
            }
        });


        // Display SalesPersons Action Listener........................................................
        displaySalesPersonsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Owner owner = new Owner();
                ArrayList<SalesPerson> salesPersons = owner.showSalesPerson();

                StringBuilder message = new StringBuilder();
                for (SalesPerson salesPerson : salesPersons) {
                    message.append(salesPerson.toString()).append("\n");
                }

                JOptionPane.showMessageDialog(null, message.toString(), "SalesPersons", JOptionPane.INFORMATION_MESSAGE);
            }
        });


        // Add SalesPerson Action Listener.............................................................
        addSalesPersonButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Create a new window for input
                JFrame inputFrame = new JFrame("Add SalesPerson");
                inputFrame.setSize(520,520);
                inputFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

                // Create input fields and labels
                JTextField nameField = new JTextField();
                JTextField phoneField = new JTextField();
                JTextField emailField = new JTextField();
                JTextField idField = new JTextField();
                JTextField passwordField = new JTextField();

                // Create a button for submitting the input
                JButton submitButton = new JButton("Add SalesPerson");
                submitButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        // Retrieve the input values
                        String name = nameField.getText();
                        String phone = phoneField.getText();
                        String email = emailField.getText();
                        String id = idField.getText();
                        String password = passwordField.getText();

                        // Validate input fields
                        if (name.isEmpty() || phone.isEmpty() || email.isEmpty()) {
                            JOptionPane.showMessageDialog(inputFrame, "Please enter all required fields.");
                            return;
                        }
                        if (Utility.verifyName(name).equalsIgnoreCase("NULL") || Utility.verifyEmail(email).equalsIgnoreCase("NULL") || Utility.verifyPhone(phone).equalsIgnoreCase("NULL"))
                        {
                            JOptionPane.showMessageDialog(inputFrame, "Please Enter Valid fields.");
                            return;
                        }

                        // Create a SalesPerson object
                        SalesPerson salesPerson = new SalesPerson(name, phone, email, id, password);

                        // Call the addSalesPerson method
                        Owner owner = new Owner();
                        boolean success = owner.addSalesPerson(salesPerson);

                        // Display error or success dialogue based on the result
                        if (success) {
                            JOptionPane.showMessageDialog(inputFrame, "SalesPerson added successfully!");
                        } else {
                            JOptionPane.showMessageDialog(inputFrame, "Failed to add SalesPerson. Please try again.");
                        }

                        // Close the input window
                        inputFrame.dispose();
                    }
                });

                // Create a panel and add input fields and submit button to it
                JPanel panel = new JPanel();
                panel.setLayout(new GridLayout(6, 2));
                panel.add(new JLabel("Name:"));
                panel.add(nameField);
                panel.add(new JLabel("Phone:"));
                panel.add(phoneField);
                panel.add(new JLabel("Email:"));
                panel.add(emailField);
                panel.add(new JLabel("ID:"));
                panel.add(idField);
                panel.add(new JLabel("Password:"));
                panel.add(passwordField);
                panel.add(submitButton);

                // Add the panel to the input frame and display it
                inputFrame.getContentPane().add(panel);
//                inputFrame.pack();
                inputFrame.setVisible(true);
            }
        });


        // Delete SalesPerson Action Listener..........................................................
        deleteSalesPersonButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Create a new window for input
                JFrame inputFrame = new JFrame("Delete SalesPerson");
                inputFrame.setSize(520,520);
                inputFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

                // Create input fields and labels
                JTextField nameField = new JTextField();
                JTextField emailField = new JTextField();

                // Create a button for submitting the input
                JButton submitButton = new JButton("Submit");
                submitButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        // Retrieve the input values
                        String name = nameField.getText();
                        String email = emailField.getText();

                        // Call the deleteSalesPerson method
                        Owner owner = new Owner();
                        boolean success = owner.deleteSalesPerson(name, email);

                        // Display error or success dialogue based on the result
                        if (success) {
                            JOptionPane.showMessageDialog(inputFrame, "SalesPerson deleted successfully!");
                        } else {
                            JOptionPane.showMessageDialog(inputFrame, "Failed to delete SalesPerson. Please try again.");
                        }

                        // Close the input window
                        inputFrame.dispose();
                    }
                });

                // Create a panel and add input fields and submit button to it
                JPanel panel = new JPanel();
                panel.setLayout(new GridLayout(3, 2));
                panel.add(new JLabel("Name:"));
                panel.add(nameField);
                panel.add(new JLabel("Email:"));
                panel.add(emailField);
                panel.add(submitButton);

                // Add the panel to the input frame and display it
                inputFrame.getContentPane().add(panel);
//                inputFrame.pack();
                inputFrame.setVisible(true);
            }
        });


        // Show Sales Record Action Listener...........................................................
        showSalesRecordButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Owner owner = new Owner();
                ArrayList<String> salesRecordDetails = owner.showSalesRecord();

                // Create a new window to display the sales record details
                JFrame salesRecordFrame = new JFrame("Sales Record");
                salesRecordFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                JTextArea salesRecordTextArea = new JTextArea(20, 50);
                salesRecordTextArea.setEditable(false);

                // Add the sales record details to the text area
                for (String record : salesRecordDetails) {
                    salesRecordTextArea.append(record + "\n");
                }

                // Add the text area to a scroll pane
                JScrollPane scrollPane = new JScrollPane(salesRecordTextArea);
                salesRecordFrame.getContentPane().add(scrollPane);

                // Set the size and make the window visible
                salesRecordFrame.pack();
                salesRecordFrame.setVisible(true);
            }
        });

        // Clear Sales Record Action Listener..........................................................
        clearSalesRecordButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int choice = JOptionPane.showConfirmDialog(null, "Are you sure you want to clear the sales record?", "Confirm Clear Sales Record", JOptionPane.YES_NO_OPTION);

                if (choice == JOptionPane.YES_OPTION) {
                    Owner owner = new Owner();
                    boolean success = owner.deleteSalesRecord();

                    if (success) {
                        JOptionPane.showMessageDialog(null, "Sales record cleared successfully!");
                    } else {
                        JOptionPane.showMessageDialog(null, "Failed to clear sales record. Please try again.");
                    }
                }
            }
        });


        // Update Account Balance Action Listener..............................................................
        updateAccountButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Create a new window for input
                JFrame inputFrame = new JFrame("Update Account Balance");
                inputFrame.setSize(520,520);
                inputFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

                // Create input fields and labels
                JTextField balanceField = new JTextField();
                JTextField revenueField = new JTextField();

                // Create a button for submitting the input
                JButton submitButton = new JButton("Modify Wallet");
                submitButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        // Retrieve the input values
                        Double updatedBalance = Double.parseDouble(balanceField.getText());
                        Double updatedRevenue = Double.parseDouble(revenueField.getText());

                        // Call the updateBalances method
                        boolean success = Utility.updateBalances(updatedBalance, updatedRevenue);

                        // Display success or error message based on the result
                        if (success) {
                            JOptionPane.showMessageDialog(inputFrame, "Account updated successfully!");
                        } else {
                            JOptionPane.showMessageDialog(inputFrame, "Failed to update account. Please try again.");
                        }

                        // Close the input window
                        inputFrame.dispose();
                    }
                });

                // Create a panel and add input fields and submit button to it
                JPanel panel = new JPanel();
                panel.setLayout(new GridLayout(3, 2));
                panel.add(new JLabel("New Balance:"));
                panel.add(balanceField);
                panel.add(new JLabel("New Revenue:"));
                panel.add(revenueField);
                panel.add(submitButton);

                // Add the panel to the input frame and display it
                inputFrame.getContentPane().add(panel);
//                inputFrame.pack();
                inputFrame.setVisible(true);
            }
        });


        // Logout button action listener......................................................
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                optionsFrame.dispose(); // Close the options window
                OwnerGUI ownerGUI = new OwnerGUI(); // Open the login window
            }
        });

        optionsPanel.add(showProfileButton);
        optionsPanel.add(updateLoginButton);
        optionsPanel.add(displayProductStockButton);
        optionsPanel.add(addNewProductButton);
        optionsPanel.add(addExistingProductButton);
        optionsPanel.add(deleteProductButton);
        optionsPanel.add(displaySalesPersonsButton);
        optionsPanel.add(addSalesPersonButton);
        optionsPanel.add(deleteSalesPersonButton);
        optionsPanel.add(showSalesRecordButton);
        optionsPanel.add(clearSalesRecordButton);
        optionsPanel.add(updateAccountButton);
        optionsPanel.add(logoutButton);



        optionsFrame.add(optionsPanel, BorderLayout.CENTER);
        optionsFrame.setLocationRelativeTo(null);
        optionsFrame.setVisible(true);
    }
}
