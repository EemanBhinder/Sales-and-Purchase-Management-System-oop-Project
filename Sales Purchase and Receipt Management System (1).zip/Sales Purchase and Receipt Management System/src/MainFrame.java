import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {
    private JLabel label0;
    private JLabel label1;
    private JLabel label2;

    private JButton owner;
    private JButton salesPerson;

    MainFrame() {
        this.setVisible(true);
        this.setSize(520, 520);
        this.setTitle("MEDICS PHARMACY, ISLAMABAD");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);

        ImageIcon logo = new ImageIcon("Logo.png");
        this.setIconImage(logo.getImage());

        Color logoColor = new Color(0, 128, 0); // Green color of the logo

        this.getContentPane().setBackground(Color.lightGray);
        JPanel panel1 = new JPanel(new BorderLayout());
        JPanel panel2 = new JPanel();
        panel2.setBackground(Color.WHITE);
        setBackground(Color.WHITE);
        panel2.setLayout(null);

        label0 = new JLabel("MEDICS PHARMACY");
        label1 = new JLabel("(Islamabad)");
        label2 = new JLabel("Choose Your Option:");

        owner = new JButton("Owner");
        salesPerson = new JButton("SalesPerson");

        // Setting Bounds
        label0.setBounds(70, 50, 400, 30);
        label0.setFont(new Font("Algerian", Font.BOLD, 38));
        // label0.setForeground(logoColor); // Set color to match the logo color
        panel2.add(label0);

        label1.setBounds(160, 80, 200, 50); // Adjusted the y-coordinate to align with other labels
        label1.setFont(new Font("Aharoni", Font.BOLD, 30));
        // label1.setForeground(logoColor); // Set color to match the logo color
        label1.setHorizontalTextPosition(JLabel.CENTER);
        panel2.add(label1);

        label2.setBounds(150, 170, 190, 50);
        label2.setFont(new Font("Aharoni", Font.BOLD, 18));
        panel2.add(label2);

        owner.setBounds(150, 190, 80, 30); // Adjusted the y-coordinate to move the buttons up
        owner.addActionListener(e -> {
            OwnerGUI ownerGUI = new OwnerGUI();
            this.dispose();
        });

        salesPerson.setBounds(250, 190, 100, 30); // Adjusted the y-coordinate to move the buttons up
        salesPerson.addActionListener(e->{
            SalesPersonGUI salesPersonGUI = new SalesPersonGUI();
            this.dispose();
        });

        JPanel panel3 = new JPanel(new FlowLayout());
        panel3.setBackground(Color.white);
        panel3.add(owner);
        panel3.add(Box.createRigidArea(new Dimension(20, 0))); // Added space between buttons
        panel3.add(salesPerson);
        panel3.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        panel1.add(panel2, BorderLayout.CENTER);
        panel1.add(panel3, BorderLayout.PAGE_END);
        add(panel1);

        setSize(500, 350);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        setLocationRelativeTo(null);
    }
}
