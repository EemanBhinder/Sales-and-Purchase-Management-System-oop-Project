import java.io.*;
public class Product implements Serializable
{
    private static final long serialVersionUID = 8785257001383939684L;



    private String productName;
    private double productPrice;
    private int quantityInStock;
    private double weight;
    private String description;
    private  Supplier supplier;

    public Product()
    {
    }
    public Product(String productName, double productPrice, int quantityInStock, double weight, String description, Supplier supplier)
    {
        this.productName = productName;
        this.productPrice = productPrice;
        this.quantityInStock = quantityInStock;
        this.weight = weight;
        this.description = description;
        this.supplier = supplier;
    }


    public void setProductName(String productName)
    {
        this.productName = productName;
    }
    public void setProductPrice(double productPrice)
    {
        this.productPrice = productPrice;
    }
    public void setQuantity(int quantityInStock)
    {
        this.quantityInStock = quantityInStock;
    }
    public void setWeight(double weight)
    {
        this.weight = weight;
    }
    public void setDescription(String description)
    {
        this.description = description;
    }
    public void setSupplier(Supplier supplier)
    {
        this.supplier = supplier;
    }
    public String getProductName()
    {
        return productName;
    }
    public double getProductPrice()
    {
        return productPrice;
    }
    public int getQuantityInStock()
    {
        return quantityInStock;
    }
    public double getWeight()
    {
        return weight;
    }
    public String getDescription()
    {
        return description;
    }
    public Supplier getSupplier()
    {
        return supplier;
    }


    public String display()
    {
        String value = "";
        value += "\nProduct Name==> " + productName;
        value += "\nProduct Price: " + productPrice;
        value += "\nProduct Weight: " + weight;
        value += "\nProduct in Stock: " + quantityInStock;
        value += "\nDescription: " + description;
        value += "\nSupplier ID: " + supplier.getID();
        value += "\nSupplier Name: " + supplier.getName();
        value += "\nSupplier Phone: " + supplier.getPhone();
        value += "\n........................................................";
        return value;
    }
}
