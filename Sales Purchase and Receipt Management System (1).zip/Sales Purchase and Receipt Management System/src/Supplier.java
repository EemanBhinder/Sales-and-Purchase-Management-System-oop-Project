import java.io.*;
public class Supplier extends Person implements Serializable
{
    private static final long serialVersionUID = 6947560519416110057L;

    private String ID;

    public Supplier()
    {
        super();
        ID = "0000";
    }
    public Supplier(String name, String phone, String email,String id)
    {
        super(name, phone, email);
        this.ID = id;
    }
    public void setID(String ID)
    {
        this.ID = ID;
    }
    public String getID()
    {
        return ID;
    }

    @Override
    public String toString() {
        String displayString = "Supplier ID: " + ID + "\n" +
                "Supplier " + super.toString();
        return displayString;
    }

}
